# Stateful exploration contract

## Initialize and resume

Resolve a session directory outside the library checkout, such as a sibling `naming-sessions/<session-id>/`. Separate users and brands. Copy templates only for a new session; never overwrite existing records. Without write tools, keep equivalent state in chat and offer portable Markdown.

On resume, read both records, summarize the active branch and latest decision, and continue from recorded preferences. Missing state is unknown, not permission to invent previous decisions. Ask one focused question if contradictory feedback affects the next action.

For review evidence, distinguish a same-agent read-back from a fresh-context resume. A fresh reader receives only library instructions and the two current session files, without the executor's transcript, future scenario or expected answers. Record the actual input boundary and reader output outside the library; a disk read by an already informed agent does not demonstrate context isolation.

## States and transitions

| State | Action | Exit condition |
|---|---|---|
| BRIEF | Establish offer, audience, character, exclusions; ask only questions affecting direction | Enough information for contrasting previews; mark assumptions |
| METHOD_MENU (optional) | Offer a broader 3–6-operator menu when requested or real uncertainty warrants it | Direction clarified |
| UNIVERSE_MENU (optional) | Ordinarily infer two distant worlds; expand to 6–12 on request or useful uncertainty | Develop a provisional branch or user choice |
| DEEP_EXPLORE | Follow the skill, preserve sources, generate diverse clusters | Useful batch or research dead end |
| REFINE / NAVIGATE | Deepen, switch, combine, revisit, shortlist, review research, or stop | User selects next action |
| EXPORT | Return only explicitly saved names with origins and notes | User stops or returns to exploration |

States are navigation aids, not compulsory gates. A sufficiently specified ordinary brief can move directly from BRIEF to useful exploration: state concise assumptions, show 2–3 contrasting directions/names and recommend one. This is an agent provisional choice, not invented user delegation. Preserve other possibilities for later navigation. Honor direct instructions from any state without requiring repeated confirmation. Menus invite creative choices; they are not permission checks for every research step. If the user delegates direction selection, record the provisional choice and proceed. Never auto-complete because a batch or count is reached.

## Branch and candidate identity

Use stable branch IDs (`B01`) and candidate IDs (`B01-C01`). Each branch records parent, method, universe, status, source references, feedback, and next opportunities. Park rather than erase branches when switching. On revisiting, recover sources and preferences. Hybrid branches name component methods and their execution order. Do not duplicate a candidate merely because it appears on multiple branches.

Separate candidate **form** (`attested`, `adapted`, `invented`) from **evidence** (`verified`, `unverified`, `not applicable`). A verified source word does not make its adapted candidate attested. Each research-derived candidate records the exact source term, source ID, supported meaning, and transformation. Sound inventions have no fabricated etymology.

## Persistence and consent

Update the exploration log after meaningful research, feedback, branching, or selection. Keep it compact but preserve enough references to recover parked paths. Detailed evidence may live in a session-owned `RESEARCH_NOTES.md`, outside the library.

Save only explicitly selected candidates to the shortlist. Praise alone is not a save instruction. Clarify ambiguous selections. Preserve exact spelling and user comments. Removal and substantive replacement require user approval. Repeated selection updates an existing entry rather than duplicating it. Around 20–25 entries offer voluntary review without blocking additions.

Export includes name, method, universe (or not applicable), origin, form, evidence, source references, and user comments when available. Keep unresolved claims labeled. State once that clearance has not been performed. Never claim a file was saved unless the write succeeded.


## Concrete evidence and reconciliation rules

`verified` applies to an ingredient/sense actually inspected, not to effectiveness, availability or the complete invented string. A supplied ordinary-English fixture ingredient may use `not applicable` when no external research claim is made. Mixed-source candidates list evidence per source; any unresolved asserted meaning makes overall lineage evidence `unverified`. Source IDs are scoped to a session; bibliography IDs must be explicitly labeled as such.

When switching, write the former branch as parked and create a child (derivation) or sibling (new direction). Preserve IDs across revisits. An unchanged candidate reused in a new branch keeps its original candidate ID and gains a branch reference. Reconcile favorites in both files after each consent event; if only one file was written, record the incomplete write and repair before claiming persistence. Never copy templates over a resumed session.

No write tools: retain equivalent state in chat; normally show a compact summary and state that no file was saved. Provide complete portable “state” and “shortlist” fields on request or handoff, rather than repeating every field each turn. On a failed write preserve the last confirmed state and provide exportable text. A resume summary names exact favorites, active branch, parked opportunities, rejected directions and the latest actual instruction; unknown prior feedback stays unknown.

## Received-evidence boundary (internal memory and audit)

Assign received user turns stable IDs (`T01`, `T02`, …), including synthetic turns. Record `received_through` in both session files and cite the originating received turn for decisions, delegation scope, rejection and shortlist consent/comments. These are internal references, not extra questions or forms for the naming user. Agent hypotheses, provisional choices and pending questions stay explicitly labeled; they are not user preferences.

Keep exact quotes in their original language and spelling. Put translations or summaries in a separate labeled field; never present them as exact comments. Repeated selection retains the candidate ID and the prior consent/comment history with its turn IDs.

In sequential trials, the executor and any writing helper may access only the received transcript prefix. Do not read future fixture turns, expected preferences, expected comments or answer keys, even when available on disk. The trial controller supplies one turn at a time and keeps future material outside the executor's accessible context; an instruction alone is not evidence that this boundary held.

After each meaningful write, reconcile both files against that received prefix: latest decision, delegated choices, rejected directions, favorites and exact comments. Check that every asserted user fact cites a received turn and no field anticipates a later instruction. Normal session files evolve forward. For audited trials, retain immutable copies of both records at each meaningful write, labeled by received-through turn and write sequence. Append a correction event and create a later snapshot if repair is needed; never replace failed historical checkpoints or retroactively validate them using later feedback. Record final-state reconciliation and historical consistency separately.

For internal reconciliation and requested audit reports, use unique candidate IDs as the counting unit. Report `total records = conforming candidates + out-of-operator diagnostics`; divide conforming candidates into retained and rejected for the current brief. A mechanically valid but rejected candidate remains conforming; an invalid construction remains a diagnostic even if discussed. Shortlisted count is a separate subset of conforming candidates, not an additional total. Keep branch references from double-counting reused IDs and state any other counting unit explicitly.

## Ordinary presentation and internal work

Keep stable IDs, source status, exact maps, consent turns and compact reconciliation internally. Normally show only 2–3 meaningful contrasts, why each fits, a concrete drawback and a proposed reading where needed. Say “invented,” “adapted from a checked sense,” or “unverified lead” tersely; never hide a material uncertainty for brevity. Full ledgers, typed graphs, corpus arithmetic and detailed maps are available when requested or necessary to explain a material limit. All skill grids and batch sizes are private defaults; useful smaller batches are valid. Audit checkpoints, immutable snapshots, hash checks and full historical reconciliation are trial/maintenance work only, never ordinary naming-session gates or user-facing forms. Portable memory and explicit shortlist consent still apply.

## Research framing and contextual comparison

For an expanded search, freeze a concise brief: audience, problem, credible promise, difference from alternatives, voice, pronunciation target, unwanted associations, target countries/languages and assumptions. Keep a plain category descriptor (usually 2–4 words) separate from the name. Infer missing nonessential fields explicitly; ask only when the answer changes direction.

When differentiation matters, inspect a small dated sample of competitor names on their own sites. Record URLs, recurring structures, imagery and tone, then propose departures as hypotheses. This is a creative namescape, not a conflict or availability search; a small sample cannot establish market-wide uniqueness. Reuse the map across methods.

Compare promising names in the same plain introduction, descriptor and realistic use context. Separate name fit, message comprehension and personal liking. Record actual feedback separately from predicted reactions. If real participants are available, ask what they think the offer is, how they would pronounce/write the name, and which associations it evokes; do not substitute simulated respondents. Before final selection, recommend native-speaker review in relevant countries for pronunciation, slang and cultural associations. Unperformed checks remain unknown; all legal/domain clearance stays in the separate future workflow. See [research basis](research/PROCESS_RESEARCH.md).

## Parallel exploration: three or all eighteen

Offer once when the brief supports exploration, alongside useful initial contrasts: “Explore three suitable methods, or all 18 with one subagent per method?” Recommend three distinct operations suited to the brief; the user may choose all, specify methods, or continue the ordinary single-branch conversation. Do not repeat the choice or require it before a useful preview. An explicit selection authorizes that run; no second confirmation is needed. Full exploration adds breadth and work, not guaranteed quality. All current methods remain draft trials.

1. **Plan.** Read the active catalog. Freeze a run ID, brief revision, received-through turn, selected method IDs and common comparison contexts. For three, prefer different families and explain fit. For all, assign every active method exactly once (currently 18); exclude deprecated routers and archived entries. Record the expected set before dispatch.
2. **Dispatch.** Create one dedicated subagent per assigned method. Give each the same brief snapshot, its method file, source contract, shared namescape if any, relevant evidence files and any explicitly required child method. A child operation does not count as completing another assignment. Workers may infer method-specific parameters but must label them. Queue dedicated workers when concurrency is limited; do not give several assignments to one worker and call that one-subagent-per-method. If the host lacks subagents, explain this and offer sequential exploration of the same selected method set with the same coverage ledger and reconciliation. Obtain the user's choice before substituting it for an explicitly requested subagent run; never claim parallel execution occurred.
3. **Worker contract.** Return method ID, brief revision, status (completed/no-yield/blocked/failed), method-specific intermediate artifact, candidates with local IDs, exact transformations, source records, form/evidence, proposed pronunciation, fit and drawback. No-yield is valid when the method does not fit; do not manufacture candidates or source evidence. Workers must not edit shared session files, select favorites, impersonate users or launch nested workers. They may read referenced child instructions without extra delegation.
4. **Reconcile.** The conductor is the sole writer of shared state. Validate each result against its assigned operator and brief revision; keep nonconforming outputs as diagnostics. Map local source/candidate IDs into session IDs. Exact repeated spellings share one candidate ID and retain every branch and lineage; conflicting provenance stays explicit rather than upgrading evidence. Keep spelling variants separate. Preserve alternative lineages separately through shortlist export, including their distinct form/evidence fields. When the brief changes, cancel pending old work where possible or mark it stale; park old results. Start a new revision with its own expected set. Coverage is scoped to run ID plus brief revision: old results never satisfy new assignments.
5. **Check coverage.** Compare returned method IDs with the expected set. Record pending, completed, no-yield, blocked and failed assignments separately. Retry only unresolved work when useful; never describe a partial run as a completed all-method sweep. Interrupted runs resume from this ledger without silently repeating completed assignments. Distinguish settled assignments from a completed sweep: failed or blocked assignments leave the sweep incomplete even when every worker has stopped. A no-yield result counts as executed only when its artifact demonstrates that the operator was applied; an unsuitable method skipped without execution stays blocked. A completed sweep requires completed or evidenced no-yield results for every expected method in the current brief revision.
6. **Present and refine.** Show a small set of contrasting clusters with a recommendation and concrete drawbacks; retain the full candidate pool and coverage internally, available on request. Compare promising candidates in identical contexts, then deepen the user's chosen directions. Never auto-save, delete favorites or export because workers finished. Shortlist consent and user control follow the existing contract.

A worker's output is evidence of one execution, not independent per-skill acceptance or consumer validation. Host scheduling and persistence need actual tool results; prose instructions alone do not prove enforcement.
